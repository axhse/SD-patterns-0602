public class Main {
    public static void main(String[] args) {
        Configuration configuration1 = Configuration.getInstance();
        Configuration configuration2 = Configuration.getInstance();
        // Expected: true.
        System.out.println(configuration1 == configuration2);

        Application application = new Application();
        // Expected: true.
        System.out.println(application.tryConnectToDatabase());
        configuration1.databaseConnectionString = null;
        // Expected: false.
        System.out.println(application.tryConnectToDatabase());
    }
}

class Application {
    public boolean tryConnectToDatabase() {
        return Configuration.getInstance().databaseConnectionString != null;
    }
}

class Configuration {
    public String databaseConnectionString;

    private static Configuration configuration;

    protected Configuration(String databaseConnectionString) {
        this.databaseConnectionString = databaseConnectionString;
    }

    public static Configuration getInstance() {
        if (configuration == null) { // Single-threaded app, no lock required.
            configuration = loadConfiguration();
        }
        return configuration;
    }

    protected static Configuration loadConfiguration() {
        return new Configuration("<some value from file>");
    }
}